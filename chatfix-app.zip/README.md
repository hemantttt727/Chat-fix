# Chat Fix
A Gen Z Dating App built with Next.js and Firebase.