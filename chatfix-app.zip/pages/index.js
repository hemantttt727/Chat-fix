export default function Home() {
  return (
    <div>
      <h1>Welcome to Chat Fix</h1>
    </div>
  );
}
