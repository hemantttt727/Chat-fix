export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Welcome to Chat Fix</h1>
      <p>This is the Gen-Z dating app!</p>
    </div>
  );
}